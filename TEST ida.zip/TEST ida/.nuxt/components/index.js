export { default as Bascet } from '../..\\components\\Bascet.vue'
export { default as BascetCart } from '../..\\components\\BascetCart.vue'
export { default as BascetForm } from '../..\\components\\BascetForm.vue'
export { default as Cart } from '../..\\components\\Cart.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as Sidebar } from '../..\\components\\Sidebar.vue'

export const LazyBascet = import('../..\\components\\Bascet.vue' /* webpackChunkName: "components/bascet" */).then(c => c.default || c)
export const LazyBascetCart = import('../..\\components\\BascetCart.vue' /* webpackChunkName: "components/bascet-cart" */).then(c => c.default || c)
export const LazyBascetForm = import('../..\\components\\BascetForm.vue' /* webpackChunkName: "components/bascet-form" */).then(c => c.default || c)
export const LazyCart = import('../..\\components\\Cart.vue' /* webpackChunkName: "components/cart" */).then(c => c.default || c)
export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => c.default || c)
export const LazySidebar = import('../..\\components\\Sidebar.vue' /* webpackChunkName: "components/sidebar" */).then(c => c.default || c)
