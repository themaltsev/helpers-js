import Vue from 'vue'

const components = {
  Bascet: () => import('../..\\components\\Bascet.vue' /* webpackChunkName: "components/bascet" */).then(c => c.default || c),
  BascetCart: () => import('../..\\components\\BascetCart.vue' /* webpackChunkName: "components/bascet-cart" */).then(c => c.default || c),
  BascetForm: () => import('../..\\components\\BascetForm.vue' /* webpackChunkName: "components/bascet-form" */).then(c => c.default || c),
  Cart: () => import('../..\\components\\Cart.vue' /* webpackChunkName: "components/cart" */).then(c => c.default || c),
  Header: () => import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => c.default || c),
  Sidebar: () => import('../..\\components\\Sidebar.vue' /* webpackChunkName: "components/sidebar" */).then(c => c.default || c)
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
