<template>
  <div>
    <Nuxt />
  </div>
</template>


<style>
/* @import url('@/assets/media.css'); */
@import url('https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap');
body {
  font-family: 'PT Sans', sans-serif;
  min-height: 100vh;
  min-width: 320px;
}

.overflow__hidden {
  overflow: hidden!important;
}
</style>